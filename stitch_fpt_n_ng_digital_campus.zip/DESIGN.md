---
name: Living Ecosystem Campus Experience
colors:
  surface: '#fbf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fbf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#eae8e2'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c18'
  on-surface-variant: '#43474d'
  inverse-surface: '#30312d'
  inverse-on-surface: '#f3f1eb'
  outline: '#74777d'
  outline-variant: '#c4c6cd'
  surface-tint: '#4d6077'
  primary: '#001326'
  on-primary: '#ffffff'
  primary-container: '#14283d'
  on-primary-container: '#7c8fa9'
  inverse-primary: '#b4c8e3'
  secondary: '#a83916'
  on-secondary: '#ffffff'
  secondary-container: '#ff7850'
  on-secondary-container: '#6b1900'
  tertiary: '#07131d'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c2832'
  on-tertiary-container: '#838f9c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b4c8e3'
  on-primary-fixed: '#071d31'
  on-primary-fixed-variant: '#35485f'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb5a0'
  on-secondary-fixed: '#3b0900'
  on-secondary-fixed-variant: '#862200'
  tertiary-fixed: '#d8e4f2'
  tertiary-fixed-dim: '#bcc8d5'
  on-tertiary-fixed: '#111d26'
  on-tertiary-fixed-variant: '#3c4853'
  background: '#fbf9f3'
  on-background: '#1b1c18'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 4.5rem
    fontWeight: '400'
    lineHeight: 5rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 2.75rem
    fontWeight: '400'
    lineHeight: 3.25rem
    letterSpacing: -0.02em
  display-md:
    fontFamily: Newsreader
    fontSize: 3.25rem
    fontWeight: '400'
    lineHeight: 3.75rem
    letterSpacing: -0.02em
  display-md-mobile:
    fontFamily: Newsreader
    fontSize: 2.25rem
    fontWeight: '400'
    lineHeight: 2.75rem
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 2.25rem
    fontWeight: '500'
    lineHeight: 2.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Newsreader
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.875rem
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: '0'
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
  space-2xl: 5rem
---

## Brand & Style

This design system expresses a forward-looking university identity situated at the intersection of architectural presence, academic rigor, and technological vitality. Designed for prospective students, researchers, faculty, and visiting scholars, the interface rejects standard institutional SaaS tropes—avoiding saturated flat purples, generic rounded cards, and sterile dashboards. 

Instead, it draws from high-end architectural monographs and investigative journals:
- **Tone:** Authoritative, cultured, intentional, and intellectually alive.
- **Visual Style:** Contemporary Editorial Modernism. It pairs asymmetric, magazine-caliber compositions with rigorous structural discipline. 
- **Emotional Resonance:** High confidence and prestige grounded in human warmth, reflecting the physical campus—sunlit concrete, lush tropical foliage, and digital engineering labs.

## Colors

The palette establishes an immediate sense of permanence and intellectual weight:

- **Primary (`#14283D` - Midnight Navy):** The anchor of the system. Used for core brand identity, deep contrast surfaces, dominant editorial headlines, and structural rules. It carries the seriousness of traditional academia paired with deep-tech infrastructure.
- **Secondary (`#D65A35` - Terracotta Orange):** A grounded reinterpretation of university heritage orange. Evoking baked earth, regional ceramic craft, and dynamic movement, this hue is reserved strictly for primary interactive CTAs, key status indicators, and editorial emphasis.
- **Tertiary (`#697581` - Cool Slate):** Provides functional neutrality for metadata, timestamps, captions, secondary navigation links, and administrative breadcrumbs.
- **Neutral Canvas (`#F8F6F0` - Warm Ivory):** The primary page canvas. Far warmer and softer than raw digital white, it reduces visual fatigue and replicates the tactile quality of heavyweight archive paper. A secondary canvas shade (`#F1EEE5` - Sand Alabaster) is used for nested sectional containers, structural column bands, and data callouts.
- **Structure & Borders (`#E2E7E6` - Soft Mist):** Delicate, non-intrusive geometric dividers that outline modules, table borders, and editorial frames without adding heavy visual noise.
- **Pure White (`#FFFFFF`):** Deployed sparingly for crisp foreground cards, active modal dialogs, and illuminated data nodes to preserve visual elevation.

## Typography

The typography unites traditional academic prestige with clean, contemporary UI clarity:

- **Editorial Display (`Newsreader`):** Used for primary section titles, hero narratives, campus philosophy statements, and pull quotes. Featuring optical sizing and full Vietnamese diacritic support, it brings an organic, literary gravitas. Display weights remain between 400 and 500 to preserve refined stroke modulation without feeling overly decorative.
- **Interface & Text Engine (`Plus Jakarta Sans`):** Powers all dense reading, technical curriculum specs, admission charts, navigation arrays, and micro-labels. Its modern geometric profile ensures razor-sharp legibility at small sizes and high rendering stability in complex tuition matrices.
- **Typographic Rules:** 
  - Editorial uppercase headers (`label-sm`, `label-md`) should employ positive letter-spacing (`0.06em` to `0.08em`) to act as architectural signposts.
  - Large narrative headlines must apply tight line-heights and negative tracking to prevent awkward line breaks in long titles.

## Layout & Spacing

The layout is grounded in an asymmetrical 12-column architectural grid inspired by modernist publishing layouts:

- **Grid Model:** 
  - **Desktop (≥ 1280px):** 12 columns with `2.5rem` gutters and `5rem` page margins. Sections feature off-center balance—e.g., a 5-column sticky title and narrative statement paired with a 7-column content flow.
  - **Tablet (768px – 1279px):** 8 columns with `1.5rem` gutters and `2.5rem` margins. Complex dual-pane editorial spreads compress gracefully to unified vertical blocks.
  - **Mobile (< 768px):** 4 columns with `1rem` gutters and `1.25rem` margins. Sticky navigation collapses into a persistent minimal bottom dock or edge panel.
- **Vertical Rhythm:** Built around a baseline unit of `0.25rem` (4px). Structural transitions between sections require generous negative space (`space-2xl`) to communicate contemplative pacing and academic clarity.

## Elevation & Depth

This system avoids floating UI tropes, artificial neo-morphism, and colored neon dropshadows. Depth is articulated purely through tonal layers, high-precision architectural boundaries, and subtle atmospheric shifts:

- **Surface Layering:** Depth is constructed primarily by stacking `Warm Ivory (#F8F6F0)` against `Sand Alabaster (#F1EEE5)` and elevated `Pure White (#FFFFFF)` cards.
- **Structural Outlines:** Boundaries use crisp `1px` lines rendered in `Soft Mist (#E2E7E6)`. In dark or inverted modules (Midnight Navy backgrounds), borders shift to `rgba(226, 231, 230, 0.12)`.
- **Atmospheric Ambient Shadow:** When true elevation is functional (such as flyout menus, contextual research panels, and focused inputs), a soft, ultra-diffused shadow is applied:
  - `box-shadow: 0 12px 32px -4px rgba(20, 40, 61, 0.06), 0 4px 12px -2px rgba(20, 40, 61, 0.03);`
  - The shadow utilizes Midnight Navy (`#14283D`) instead of black, producing an organic depth that integrates seamlessly with the Warm Ivory canvas.

## Shapes

The geometric vernacular communicates structure, precision, and architectural permanence:

- **Curvature Hierarchy:** Standard surfaces, buttons, input fields, and tabular frames use a disciplined `0.25rem` (Soft) radius.
- **Large Contextual Blocks:** Hero imagery, primary editorial story cards, and major modal structures use `rounded-lg` (`0.5rem`).
- **Capsule Rules:** Circular and pill-shaped radiuses are strictly restricted to numeric count badges and metadata status chips. They are never used for actionable buttons or input containers, ensuring the interface maintains its architectural form.

## Components

### Buttons & Interactive Controls
- **Primary CTA:** Solid Terracotta Orange (`#D65A35`) with Pure White text, `0.25rem` radius, and horizontal padding of `1.5rem`. Hover states introduce a subtle shift to `#C24C28` accompanied by a micro-scale of `1.01`.
- **Secondary / Academic Outline:** Transparent surface with a `1px` Midnight Navy (`#14283D`) border and Midnight Navy text. Hover shifts background to `rgba(20, 40, 61, 0.04)`.
- **Tertiary / Text Link:** Midnight Navy or Terracotta text accompanied by an architectural `1px` baseline underline separated by `4px` padding.

### Cards & Editorial Story Blocks
- Rather than standard drop-shadow cards, use flush boundary frames bordered by `#E2E7E6` over `#FFFFFF` or `#F1EEE5`.
- Image ratios adhere to strict medium-format proportions (`4:3` or `16:10`). Images feature a desaturated, natural tone that warms up slightly on hover.
- Cards maintain distinct internal hierarchies: Monospace/Micro-label metadata header, large Newsreader editorial title, brief Plus Jakarta Sans summary, and a low-profile text link.

### Data Tables & Tuition Schedules
- Data displays are designed for readability, devoid of noisy zebra striping.
- Alternating rows use hairline bottom dividers (`1px solid #E2E7E6`).
- Headers are set in uppercase `label-sm` using Slate (`#697581`) with tabular, mono-spaced numbers aligned right for fee calculations, credits, and semester timelines.

### Form Inputs & Selectors
- Background: Pure White (`#FFFFFF`) with a `1px` border in `#E2E7E6`.
- Active / Focus: Border transitions to Midnight Navy (`#14283D`) with a `2px` focus ring in `rgba(214, 90, 53, 0.2)`.
- Placeholder: Subdued Cool Slate (`#697581`). Error states utilize Terracotta Orange (`#D65A35`) for high contrast readability without jarring safety-red tones.

### Badges & Metadata Chips
- Small, deliberate, and structural. Height set at `24px` with a `0.125rem` or full capsule radius depending on context.
- Surfaces use low-opacity washes (e.g., `rgba(20, 40, 61, 0.05)` for institutional tags, `rgba(214, 90, 53, 0.1)` for active application status). Text matches the respective core token.